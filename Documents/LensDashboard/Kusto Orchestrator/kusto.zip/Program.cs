﻿
namespace KLD

{

    using System;
    using Kusto.Data;
    using Kusto.Data.Common;
    using Kusto.Data.Net.Client;
    using Kusto.Cloud.Platform.Data;
    using System.Windows.Forms;
    using System.Collections.Generic;

    class Program
    {
        static void Main(string[] args)
        {
            var builder = new KustoConnectionStringBuilder("https://masvaas.kusto.windows.net/")
                .WithAadUserPromptAuthentication();


            using (var adminProvider = KustoClientFactory.CreateCslAdminProvider(builder))
            {
                var command = CslCommandGenerator.GenerateDatabasesShowCommand();
                var objectReader = new ObjectReader<DatabasesShowCommandResult>(adminProvider.ExecuteControlCommand(command));
                foreach (var temp in objectReader)
                {
                    var db = temp.DatabaseName;

                    var databaseJournalCommand = CslCommandGenerator.GenerateDatabaseJournalShowCommand(db);
                    databaseJournalCommand += " | where Event == 'ADD-DATABASE' | project EventTimestamp";
                    //hardcoded queries to get the created time for db using journal command
                    using (var journalCmdResult = adminProvider.ExecuteControlCommand(db, databaseJournalCommand))
                    {
                        
                        ///List<DateTime> dates= new List<string>() journalCmdResult["EventTimestamp"];
                        if (journalCmdResult.Read() && DateTime.TryParse(journalCmdResult["EventTimestamp"].ToString(), out var createdTime))
                        {
                            //var dat = dates.OrderByDesending() 
                            Console.WriteLine($"Database: {db}, CreationTime: {createdTime}");
                        }

                        //read the datareader2 object and parse the data and output is stored in createdTime


                    }

                }
            }
        }

    }
}